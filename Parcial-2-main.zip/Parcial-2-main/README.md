# Parcial-2
Parcial 2 de 1LS123 // Oct 2022
